package com.carochess.common;

public class Configs {
	
	public static final int MAX_ROW = 15;
	public static final int MAX_COL = 17;	
	
	public static final int MAX_WAITING_ROOM = 20;

}
