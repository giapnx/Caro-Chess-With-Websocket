package com.carochess.common;

public class RoomNode {

	public int roomId;
	public String roomName;
	
	public RoomNode(int id, String name)
	{
		roomId = id;
		roomName = name;
	}

}
